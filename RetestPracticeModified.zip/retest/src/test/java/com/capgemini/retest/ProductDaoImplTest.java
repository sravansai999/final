package com.capgemini.retest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.bean.Product;
import com.capgemini.dao.ProductDaoImpl;

public class ProductDaoImplTest {
	
	static ProductDaoImpl dao;
	static Product product;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
		dao=new ProductDaoImpl();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		dao=null;
	}

	@Before
	public void setUp() throws Exception {
		product=new Product(11,3,"Ashish",2000,78787878);
	}

	@After
	public void tearDown() throws Exception {
		product=null;
	}

	@Test
	public void testGetAllProducts() {
		assertNotNull(dao.getAllProducts());
	}

	@Test
	public void testAddProduct() {
		
		
		
	}

	@Test
	public void testDeleteCustomer() {
		dao.addProduct(product);
		assertTrue(dao.deleteCustomer(product.getId()));
	}

	@Test
	public void testUpdateProduct() {
		boolean val;
		dao.addProduct(product);
		product.setName("bgvb");
		val=dao.updateProduct(product);
		assertTrue(val);
	}
	@Test
	public void testUpdateProductFalse() {
		boolean val;
		//dao.addProduct(product);
		//product.setName("bgvb");
		assertTrue(dao.updateProduct(product));
	}

}
