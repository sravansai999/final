package com.capgemini.service;

import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bean.Product;
import com.capgemini.dao.ProductDaoImpl;
import com.capgemini.exception.retestException;



public class ProductServiceImpl implements IProductService{
     
	ProductDaoImpl dao=new ProductDaoImpl();
	
	public int addProduct(Product product)  {
		 
		
		return dao.addProduct(product);
	}
	
	
	
	
	
	
	
	
	
	@Override
	public List<Product> getAllProducts() {
		
		return dao.getAllProducts();
	}









	public boolean delete(int productId) {
		
			boolean status=dao.deleteCustomer(productId);
			if(status=true) {
				
				status=true;
			}
			
			
			return status;
		}
	
	
    public boolean isNameValid(String name) throws retestException{
        Pattern nameptn = Pattern.compile("^[A-Z]{1}[a-z]{4,}$")  ;
        Matcher match = nameptn.matcher(name) ;
        if(!match.matches())
            throw new retestException("Name should be of 5 digits and start with Capital letters") ;
        else
            return true;
       
    		
	}









	public boolean updateProduct(Product product) {
		boolean status=dao.updateProduct(product);
		if(status) {
		return status;
	}else {
		System.out.println("Customer id doesnot exists... ");
	}
	return status;	
	}









	public Product getProduct(int id) {
		
		
		
		return dao.getProduct(id);
	}









public List<Product> getProduct(String name) {
		return dao.getProduct(name);
	}









	public Map<Integer, Product> getAllProduct() {
		
		return dao.getAllProduct();
	}
		
	}










	


