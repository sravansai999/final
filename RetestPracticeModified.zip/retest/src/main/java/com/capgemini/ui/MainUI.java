package com.capgemini.ui;

import java.awt.DisplayMode;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;



import com.capgemini.bean.Product;
import com.capgemini.exception.retestException;
import com.capgemini.service.ProductServiceImpl;
import com.capgemini.utility.SortByName;
import com.capgemini.utility.SortByNumber;
import com.capgemini.utility.SortByPrice;
import com.capgemini.utility.SortBySequence;




public class MainUI {
      
	public static void main(String[] args) {
		
		
		Scanner scanner=new Scanner(System.in);
        ProductServiceImpl service=new ProductServiceImpl();
		
		List<Product> productlist=service.getAllProducts();
		for(Product product: productlist) {
			System.out.println(product);
		}
	    boolean nameFlag=false;
		boolean deleteFlag=false;
		boolean choiceFlag=false;
		boolean sequenceFlag=false;
		int choice=0;
		int sequence=0;
		String name="";
		int id=0;
		double price=0;
		long isbn=0;
	do {
		do {
		System.out.println("1.Add Product\n2.Delete product\n3.Display Product\n4.Update Product\n5.Search By Id\n6.SearchByName\n7.Show All details in List\n8.Show in arraylist\n9.Exit");
		try {
		 choice=scanner.nextInt();
		 choiceFlag=true;
		 if(choice>9) {
			 System.out.println("please enter choice less than 4");
			 choiceFlag=false;
		 }else {
			 System.out.println("proceed.....");
			 choiceFlag=true;
		 }
		}catch(InputMismatchException e) {
			System.err.println("Only Integers are permitted....");
			choiceFlag=false;
			scanner.nextLine();
		}}while(!choiceFlag);
		switch(choice) {
		
		
case 1:{
			do 
		{
			System.out.println("Enter Sequence Number");
			
			
			try {
				sequence = scanner.nextInt();
				sequenceFlag=true;
			} catch (InputMismatchException e) {
				
			System.err.println("Only numbers are permitted.....");
			sequenceFlag=false;
			scanner.nextLine();
			}
			}while(!sequenceFlag);
			do {
		    System.out.println("Enter the Name of Product");
			name=scanner.next();
			try {
				service.isNameValid(name);
				nameFlag=true;
			} catch (retestException e) {
				System.err.println(e.getMessage());
			}}while(!nameFlag);
			
			System.out.println("Enter Price of Product");
			 price=scanner.nextDouble();
			
			System.out.println("Enter ISBN Number");
			 isbn=scanner.nextLong();
			
			Product product=new Product(0,sequence,name,price,isbn);
			int productId=service.addProduct(product);
			System.out.println("product added successfully with product id:"+productId);
			
		} break;
case 2:{
			do {
			System.out.println("Enter Product Id to delete");
			int productId=scanner.nextInt();
			
			boolean status=service.delete(productId);
			if(status=true) {
				System.out.println( productId+ "  Deleted Successfully......");
				deleteFlag=true;
			}else {
				System.out.println("Id not available...");
				
			}
				
		}while(!deleteFlag);
		}break;
case 3:{
		
			System.out.println("Enter Option \n1.SortByName \n2.SortByPrice \n3.SortByNumber \n4.SortBySequence");
		    int option=scanner.nextInt();
		    switch(option) {
		
		
		
	case 1:{
			List<Product> productlistbyname=service.getAllProducts();
			Collections.sort(productlistbyname, new SortByName());
			display(productlistbyname);
		}
		break;
	case 2:{
		
			List<Product> productlistbyprice=service.getAllProducts();
			Collections.sort(productlistbyprice, new SortByPrice());
			display(productlistbyprice);
		}
		break;
	case 3:{
			List<Product> productlistbyNumber=service.getAllProducts();
			Collections.sort(productlistbyNumber, new SortByNumber());
			display(productlistbyNumber);
		}break;
	case 4:{
			List<Product> productlistbySequence=service.getAllProducts();
			Collections.sort(productlistbySequence, new SortBySequence());
			display(productlistbySequence);
		}break;
		    }
		
		}break;
case 4:{
	       System.out.println("Enter Id to update");
	        id=scanner.nextInt();
	       System.out.println("Enter Sequence Number");
	       sequence=scanner.nextInt();
	       System.out.println("Enter Name of Product");
	       name=scanner.next();
	       System.out.println("Enter Price of the Product");
	       price=scanner.nextDouble();
	       System.out.println("Enter GSN Number");
	       isbn=scanner.nextLong();
	       Product product=new Product(id,sequence,name,price,isbn);
	       boolean status=service.updateProduct(product);
	       if(status){
				System.out.println("Updated Successfully.......");
			}else {
				System.out.println("Id doesnot exist in Database:");
			};
	
}break;
case 5:{  
	      System.out.println("***********Product***************");
	      System.out.println("Enter Product Id to Search..");
	      id=scanner.nextInt();
	      Product p=service.getProduct(id);
	      System.out.println(p);
}break;
case 6:{
	      System.out.println("Enter Product Name To Search");
	      name=scanner.next();
	     List<Product> li = service.getProduct(name);
	     System.out.println(li);
	
}break;
case 7:{ System.out.println("*******List View************");
           List<Product> list1 = service.getAllProducts();
           for (java.util.Iterator iterator = list1.iterator(); iterator.hasNext();) {
			Product product = (Product) iterator.next();
			System.out.println(product);
		}
} 
case 8:{
	      Map<Integer, Product> map1 = service.getAllProduct();

	      Iterator<Integer> iterator = map1.keySet().iterator();
	      while (iterator.hasNext()) {
		      id = iterator.next();
		    Product vehicleData = map1.get(id);
		    System.out.println(id + ": " + vehicleData);
	}break;

	      
}
case 9:{
			System.out.println("Thanks for visiting......");
			System.exit(0);
		}

		
	}
	}while(true);
	}
	
	static void display(List<Product> productlist) {
		for(Product product: productlist) {
			System.out.println(product);
		
	
	}
	}
	}


	

	


